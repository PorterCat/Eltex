#!/bin/bash
set -u

SELF=$(basename "$0")
NAME="${SELF%.sh}"

if [ "$SELF" = "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 0
fi

LOG="report_${NAME}.log"
PID=$$
DATE=$(date '+%Y-%m-%d %H:%M:%S')
echo "$DATE [$PID] Скрипт запущен" >> "$LOG"

CUCKOO_PID=""
FIFO=""
for p in /proc/[0-9]*; do
    [ -r "$p/cmdline" ] || continue
    tr '\0' '\n' < "$p/cmdline" 2>/dev/null | grep -q 'cuckoo\.sh' || continue
    for arg in $(tr '\0' '\n' < "$p/cmdline" 2>/dev/null); do
        case "$arg" in
            --pishitesuda=*) FIFO="${arg#--pishitesuda=}" ;;
        esac
    done
    [ -n "$FIFO" ] && { CUCKOO_PID=${p#/proc/}; break; }
done

if [ -z "$FIFO" ] || [ ! -p "$FIFO" ]; then
    DATE=$(date '+%Y-%m-%d %H:%M:%S')
    echo "$DATE [$PID] Канал cuckoo.sh не найден, выхожу" >> "$LOG"
    exit 1
fi

echo "$SELF[$PID]: how much time do I have?" > "$FIFO"
if ! read -t 10 -r N < "$FIFO"; then
    DATE=$(date '+%Y-%m-%d %H:%M:%S')
    echo "$DATE [$PID] Ответ от cuckoo.sh не получен" >> "$LOG"
    exit 1
fi
case "$N" in ''|*[!0-9]*) N=0 ;; esac

sleep "$N"

DATE=$(date '+%Y-%m-%d %H:%M:%S')
echo "$DATE [$PID] Скрипт завершился, работал $N секунд." >> "$LOG"
