#!/bin/bash
set -u

BASE=$(cd "$(dirname "$0")" && pwd)
CONF="$BASE/observer.conf"
LOG="$BASE/observer.log"

[ -f "$CONF" ] || { echo "no config $CONF" >&2; exit 1; }

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"; }

is_running() {
    local target="$1" p pid
    for p in /proc/[0-9]*; do
        [ -r "$p/cmdline" ] || continue
        pid=${p#/proc/}
        [ "$pid" = "$$" ] && continue
        if tr '\0' '\n' < "$p/cmdline" 2>/dev/null | grep -Fxq "$target"; then
            return 0
        fi
    done
    return 1
}

while IFS= read -r line; do
    case "$line" in
        ''|\#*) continue ;;
    esac
    script="$line"
    if is_running "$script"; then
        continue
    fi
    ( cd "$(dirname "$script")" && nohup "$script" >/dev/null 2>&1 & )
    log "Перезапущен $script"
done < "$CONF"
